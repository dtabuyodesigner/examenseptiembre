package com.danieltabuyo.examenentornosseptiembre.examensalonjuegos;

public class Avatar {
	
	private String aspecto;
	private String nivel;
	
	
	//Método constructor de avatares
	public Avatar(String aspecto, String nivel) {
		this.aspecto = aspecto;
		this.nivel = nivel;
		
		
	}
//Getters y Setters

	public String getAspecto() {
		return aspecto;
	}


	public void setAspecto(String aspecto) {
		this.aspecto = aspecto;
	}


	public String getNivel() {
		return nivel;
	}


	public void setNivel(String nivel) {
		this.nivel = nivel;
	}
//Método toStringo
	@Override
	public String toString() {
		return "Datos del Avatar [aspecto=" + aspecto + ", nivel=" + nivel + "]";
	}
	
	

}
