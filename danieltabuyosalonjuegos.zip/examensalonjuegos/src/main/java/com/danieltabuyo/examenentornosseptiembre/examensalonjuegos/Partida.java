package com.danieltabuyo.examenentornosseptiembre.examensalonjuegos;

import java.util.Date;
import java.util.GregorianCalendar;

public class Partida {
	
	
	private int  codigo;
	private String nombre;
	private String pass;
	private Date fecha;
	private String salon;
	private String hora_creacion;
	private boolean estado = true;
	private String avatar_creador;
	private static final String tipo_juego = "";
	

	// Método constructor de la partida
	public Partida(int codigo, String nombre, String pass, int ano, int mes, int dia, String salon, String hora_creacion, boolean estado,
			String avatar_creador) {
		this.codigo = codigo;
		this.nombre = nombre;
		this.pass = pass;
		this.fecha = fecha;
		this.salon = salon;
		this.hora_creacion = hora_creacion;
		this.estado = estado;
		this.avatar_creador = avatar_creador;
		GregorianCalendar calendario = new GregorianCalendar(ano, mes - 1, dia);
		fecha = calendario.getTime();
	}

//getters y setters

	public int getCodigo() {
		return codigo;
	}



	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}



	public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public String getPass() {
		return pass;
	}



	public void setPass(String pass) {
		this.pass = pass;
	}



	public Date getFecha() {
		return fecha;
	}



	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}



	public String getSalon() {
		return salon;
	}



	public void setSalon(String salon) {
		this.salon = salon;
	}



	public String getHora_creacion() {
		return hora_creacion;
	}



	public void setHora_creacion(String hora_creacion) {
		this.hora_creacion = hora_creacion;
	}



	public boolean isEstado() {
		return estado;
	}



	public void setEstado(boolean estado) {
		this.estado = estado;
	}



	public String getAvatar_creador() {
		return avatar_creador;
	}



	public void setAvatar_creador(String avatar_creador) {
		this.avatar_creador = avatar_creador;
	}



	public static String getTipoJuego() {
		return tipo_juego;
	}

//Método toString
	@Override
	public String toString() {
		return "Los datos de la Partida son: [codigo=" + codigo + ", nombre=" + nombre + ", pass=" + pass + ", fecha="
				+ fecha + ", salon=" + salon + ", hora_creacion=" + hora_creacion + ", estado=" + estado
				+ ", avatar_creador=" + avatar_creador + "]";
	}
	
	
	

}
