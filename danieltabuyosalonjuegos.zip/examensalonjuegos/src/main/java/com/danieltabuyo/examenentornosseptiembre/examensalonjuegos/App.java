package com.danieltabuyo.examenentornosseptiembre.examensalonjuegos;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App {
	static ArrayList<Avatar> misavatares = new ArrayList<Avatar>();
	static ArrayList<Partida> mispartidas = new ArrayList<Partida>();
	static ArrayList<Jugador> misjugadores = new ArrayList<Jugador>();

	// Variables Scanner para recoger lo que se introduce por teclado
	static Scanner sc = new Scanner(System.in);

	// CREACIÓN DE LOS MÉTODOS

//		RegistrarUsuario

	public static void RegistrarUsuario() {
		String nombre;
		String mail;
		String login;
		String nick;
		String pass;

		System.out.println("Introduce tu nombre");
		nombre = sc.next();
		System.out.println("Introduce tu mail");
		mail = sc.next();
		System.out.println("Introduce tu login");
		login = sc.next();
		if (login.equals(login)) {
			System.out.println("Login ya existe. Introduce un nuevo login");
			login = sc.next();

		}

		System.out.println("Introduce tu nick");
		nick = sc.next();
		System.out.println("Introduce tu pass");
		pass = sc.next();

		Jugador jugador = new Jugador(nombre, mail, nick, login, pass);

		misjugadores.add(jugador);

	}
	// Método crearPartida

	public static void main(String[] args) {

		// creo algunas instancias y las almaceno en su array

		Jugador jugador1 = new Jugador("Carlos", "carlos@gmail.com", "carlitos", "carlosV", "deEspaña");
		Jugador jugador2 = new Jugador("Pepe", "pepe@gmail.com", "pepote", "pepillogrillo", "aguanta");
		Jugador jugador3 = new Jugador("Nerea", "nerea@gmail.com", "nereita", "lamasdiva", "deParla");
		Jugador jugador4 = new Jugador("Matilde", "mati@gmail.com", "matimati", "matahari", "delPoligamo");

		misjugadores.add(jugador1);
		misjugadores.add(jugador2);
		misjugadores.add(jugador3);
		misjugadores.add(jugador4);

		RegistrarUsuario();

		for (Jugador j : misjugadores) {

			System.out.println(misjugadores.toString());
			System.out.println();

		}

	}
}
