package com.danieltabuyo.examenentornosseptiembre.examensalonjuegos;

public class Jugador {

	private String nombre;
	private String mail;
	private String nick;
	private String login;
	private String pass;

	// Método constructor
	public Jugador(String nombre, String mail, String nick, String login, String pass) {
		this.nombre = nombre;
		this.mail = mail;
		this.nick = nick;
		this.login = login;
		this.pass = pass;
	}

	// Getters y Setters
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}
	// Métodos del jugador

	public void crearAvatar() {

	}

	public void crearPartida() {

	}

	public void visitarSalones() {

	}

	public void jugar() {

	}

	// Método toString
	@Override
	public String toString() {
		return "\n***DATOS DEL JUGADOR*** \nNombre: " + nombre + "\nMail: " + mail + "\n Login: " + login + "\nNick: "
				+ nick + "\nPass: " + pass;

	}
}
