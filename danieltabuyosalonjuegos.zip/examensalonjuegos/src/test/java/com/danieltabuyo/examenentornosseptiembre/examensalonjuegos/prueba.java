package com.danieltabuyo.examenentornosseptiembre.examensalonjuegos;

import static org.junit.Assert.*;

import org.junit.Test;

public class prueba {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
